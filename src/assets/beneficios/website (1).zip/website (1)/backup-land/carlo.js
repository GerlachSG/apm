document.addEventListener("DOMContentLoaded", () => {
    // Registrar plugin GSAP e criar ease personalizado
    gsap.registerPlugin(CustomEase);
    CustomEase.create(
        "hop",
        "M0,0 C0.488,0.082 0.467,0.286 0.5,0.5 0.532,0.712 0.561,1 1,1"
    );

    // Elementos do DOM
    const slider = document.querySelector(".slider");
    const sliderTitle = document.querySelector(".slider-title");
    const sliderCounter = document.querySelector(
        ".slider-counter p span:first-child"
    );
    const sliderItems = document.querySelector(".slider-items");
    const sliderPreview = document.querySelector(".slider-preview");
    
    // Configurações do slider
    const totalSlides = 6; // Corresponde ao tamanho do array sliderContent
    let activeSlideIndex = 1;
    let isAnimating = false;

    // Conteúdo dos slides
    const sliderContent = [
        { name: "Dia das Mulheres", img: "./assets/img1.png" },
        { name: "Novo E-Commerce APPM", img: "./assets/img2.png" },
        { name: "Conscientização Setembro", img: "./assets/img3.png" },
        { name: "Dia do Autista", img: "./assets/img4.jpg" },
        { name: "Gincana 2025", img: "./assets/img5.jpg" },
        { name: "Projetos para o Mundo", img: "./assets/img6.png" },
    ];

    // Configurações de clipPath para transições
    const clipPath = {
        closed: "polygon(25% 30%, 75% 30%, 75% 70%, 25% 70%)",
        open: "polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)",
    };

    // Posições e rotações para cada estado de slide
    const slidePositions = {
        prev: { left: "15%", rotation: -90 },
        active: { left: "50%", rotation: 0 },
        next: { left: "85%", rotation: 90 },
    };

    // Função para dividir texto em spans individuais (para animação letra por letra)
    function splitTextIntoSpans(element) {
        element.innerHTML = element.innerText
            .split("")
            .map((char) => `<span>${char === " " ? "&nbsp;&nbsp;" : char}</span>`)
            .join("");
    }

    // Função para criar e animar o título
    function createAndAnimateTitle(content, direction) {
        const newTitle = document.createElement("h1");
        newTitle.innerText = content.name;
        sliderTitle.appendChild(newTitle);
        splitTextIntoSpans(newTitle);

        const yOffset = direction === "next" ? 60 : -60;
        gsap.set(newTitle.querySelectorAll("span"), { y: yOffset });
        gsap.to(newTitle.querySelectorAll("span"), {
            y: 0,
            duration: 1.25,
            stagger: 0.02,
            ease: "hop",
            delay: 0.25,
        });

        const currentTitle = sliderTitle.querySelector("h1:not(:last-child)");
        if (currentTitle) {
            gsap.to(currentTitle.querySelectorAll("span"), {
                y: -yOffset,
                duration: 1.25,
                stagger: 0.02,
                ease: "hop",
                delay: 0.25,
                onComplete: () => currentTitle.remove(),
            });
        }
    }

    // Função para criar um novo slide
    function createSlide(content, className) {
        const slide = document.createElement("div");
        slide.className = `slider-container ${className}`;
        slide.innerHTML = `<div class="slide-img"><img src="${content.img}" alt="${content.name}"></div>`;
        return slide;
    }

    // Função para calcular o índice do slide com base no incremento
    function getSlideIndex(increment) {
        return ((activeSlideIndex + increment - 1 + totalSlides) % totalSlides) + 1;
    }

    // Função para atualizar o contador e destacar o item atual
    function updateCounterAndHighlight(index) {
        sliderCounter.textContent = index;
        sliderItems.querySelectorAll("p").forEach((item, i) => 
            item.classList.toggle("activeItem", i === index - 1)
        );
    }

    // Função para atualizar a imagem de preview
    function updatePreviewImage(content) {
        const newImage = document.createElement("img");
        newImage.src = content.img;
        newImage.alt = content.name;
        sliderPreview.appendChild(newImage);

        gsap.fromTo(
            newImage,
            {
                opacity: 0
            },
            {
                opacity: 1,
                duration: 1,
                ease: "power2.inOut",
                delay: 0.5,
                onComplete: () => {
                    // Apenas remove a imagem antiga se houver uma
                    const oldImage = sliderPreview.querySelector("img:not(:last-child)");
                    if (oldImage) oldImage.remove();
                }
            }
        );
    }

    // Função para animar um slide
    function animateSlide(slide, props) {
        if (!slide) return;
        
        gsap.to(slide, { 
            ...props, 
            duration: 2, 
            ease: "hop" 
        });
        
        const slideImg = slide.querySelector(".slide-img");
        if (slideImg) {
            gsap.to(slideImg, {
                rotation: -props.rotation,
                duration: 2,
                ease: "hop",
            });
        }
    }

    // Função principal para transições de slides
    function transitionSlides(direction) {
        if (isAnimating) return;
        isAnimating = true;

        const [outgoingPos, incomingPos] =
            direction === "next" ? ["prev", "next"] : ["next", "prev"];

        const outgoingSlide = slider.querySelector(`.${outgoingPos}`);
        const activeSlide = slider.querySelector(".active");
        const incomingSlide = slider.querySelector(`.${incomingPos}`);

        if (!outgoingSlide || !activeSlide || !incomingSlide) {
            isAnimating = false;
            console.error("Elementos de slide não encontrados");
            return;
        }

        // Animação do slide que está entrando para se tornar ativo
        animateSlide(incomingSlide, {
            ...slidePositions.active,
            clipPath: clipPath.open,
        });

        // Animação do slide atual para se tornar o slide que sai
        animateSlide(activeSlide, {
            ...slidePositions[outgoingPos],
            clipPath: clipPath.closed,
        });

        // IMPORTANTE: Não remover o slide que está saindo do DOM
        // Apenas animar sua escala para 0, mas manter o elemento
        gsap.to(outgoingSlide, { 
            scale: 0, 
            opacity: 0, 
            duration: 1.5, 
            ease: "hop" 
        });

        // Calculando índices para o novo slide
        const newActiveIndex = getSlideIndex(direction === "next" ? 1 : -1);
        const newSlideIndex = getSlideIndex(direction === "next" ? 2 : -2);
        
        // Criando novo slide para substituir o que está saindo
        const newSlide = createSlide(sliderContent[newSlideIndex - 1], incomingPos);
        slider.appendChild(newSlide);
        
        // Configuração inicial do novo slide
        gsap.set(newSlide, {
            ...slidePositions[incomingPos],
            xPercent: -50,
            yPercent: -50,
            clipPath: clipPath.closed,
            opacity: 0,
            scale: 0,
        });
        
        // Configuração da rotação da imagem no novo slide
        gsap.set(newSlide.querySelector(".slide-img"), {
            rotation: -slidePositions[incomingPos].rotation,
        });
        
        // Animação para fazer o novo slide aparecer
        gsap.to(newSlide, { 
            scale: 1, 
            opacity: 1, 
            duration: 1.5, 
            ease: "hop" 
        });

        // Atualizar título e imagem de preview
        createAndAnimateTitle(sliderContent[newActiveIndex - 1], direction);
        updatePreviewImage(sliderContent[newActiveIndex - 1]);

        // Atualizar contador após um breve atraso
        setTimeout(() => updateCounterAndHighlight(newActiveIndex), 1000);

        // Limpeza e finalização após a animação
        setTimeout(() => {
            // Agora sim, remover o slide antigo quando a animação terminar
            if (outgoingSlide && outgoingSlide.parentNode) {
                outgoingSlide.remove();
            }
            
            // Atualizar classes para refletir os novos estados
            if (activeSlide) activeSlide.className = `slider-container ${outgoingPos}`;
            if (incomingSlide) incomingSlide.className = "slider-container active";
            if (newSlide) newSlide.className = `slider-container ${incomingPos}`;
            
            // Atualizar índice ativo e permitir novas animações
            activeSlideIndex = newActiveIndex;
            isAnimating = false;
        }, 2000);
    }

    // Inicialização do slider
    function initializeSlider() {
        // Limpar o slider para garantir que não haja elementos residuais
        // mas preservar elementos de fundo se houver
        const backgroundElements = Array.from(slider.children).filter(
            child => !child.classList.contains("slider-container")
        );
        
        // Armazenar temporariamente elementos de fundo
        const tempContainer = document.createElement("div");
        backgroundElements.forEach(el => tempContainer.appendChild(el));
        
        // Limpar o slider
        slider.innerHTML = '';
        
        // Restaurar elementos de fundo
        while (tempContainer.firstChild) {
            slider.appendChild(tempContainer.firstChild);
        }
        
        // Criar os três slides iniciais (prev, active, next)
        const prevIndex = getSlideIndex(-1);
        const activeIndex = activeSlideIndex;
        const nextIndex = getSlideIndex(1);
        
        const prevSlide = createSlide(sliderContent[prevIndex - 1], "prev");
        const activeSlide = createSlide(sliderContent[activeIndex - 1], "active");
        const nextSlide = createSlide(sliderContent[nextIndex - 1], "next");
        
        slider.appendChild(prevSlide);
        slider.appendChild(activeSlide);
        slider.appendChild(nextSlide);
        
        // Aplicar posições iniciais
        Object.entries(slidePositions).forEach(([key, value]) => {
            const slideElements = slider.querySelectorAll(`.slider-container.${key}`);
            slideElements.forEach(slideElement => {
                gsap.set(slideElement, {
                    ...value,
                    xPercent: -50,
                    yPercent: -50,
                    clipPath: key === "active" ? clipPath.open : clipPath.closed,
                });
                
                if (key !== "active") {
                    const imgElement = slideElement.querySelector(".slide-img");
                    if (imgElement) {
                        gsap.set(imgElement, {
                            rotation: -value.rotation,
                        });
                    }
                }
            });
        });
        
        // Configurar imagem de preview inicial
        if (sliderPreview && !sliderPreview.querySelector("img")) {
            updatePreviewImage(sliderContent[activeIndex - 1]);
        }
        
        // Criar título inicial se não existir
        if (!sliderTitle.querySelector("h1")) {
            const newTitle = document.createElement("h1");
            newTitle.innerText = sliderContent[activeIndex - 1].name;
            sliderTitle.appendChild(newTitle);
            splitTextIntoSpans(newTitle);
            gsap.fromTo(
                newTitle.querySelectorAll("span"),
                { y: 60 },
                { y: 0, duration: 1, stagger: 0.02, ease: "hop" }
            );
        }
    }

    // Event listener para cliques no slider
    slider.addEventListener("click", (e) => {
        const clickedSlide = e.target.closest(".slider-container");
        if (clickedSlide && !isAnimating) {
            transitionSlides(
                clickedSlide.classList.contains("next") ? "next" : "prev"
            );
        }
    });

    // Inicializar o slider
    initializeSlider();

    // Animar o título inicial
    const initialTitle = sliderTitle.querySelector("h1");
    if (initialTitle) {
        splitTextIntoSpans(initialTitle);
        gsap.fromTo(
            initialTitle.querySelectorAll("span"),
            { y: 60 },
            { y: 0, duration: 1, stagger: 0.02, ease: "hop" }
        );
    }

    // Destacar o item atual no menu
    updateCounterAndHighlight(activeSlideIndex);

    // Adicionar event listeners aos itens do menu
    sliderItems.querySelectorAll("p").forEach((item, index) => {
        item.addEventListener("click", () => {
            if (index + 1 !== activeSlideIndex && !isAnimating) {
                transitionSlides(index + 1 > activeSlideIndex ? "next" : "prev");
            }
        });
    });
});